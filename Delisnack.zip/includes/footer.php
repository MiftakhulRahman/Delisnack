</div> <!-- Closing main-content div -->
    <script src="/assets/js/script.js"></script>
</body>
</html>